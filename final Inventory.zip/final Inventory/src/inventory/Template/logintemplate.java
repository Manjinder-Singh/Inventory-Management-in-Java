/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package inventory.Template;

/**
 *
 * @author SIMI
 */
public class logintemplate {
    String username,password;

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}
