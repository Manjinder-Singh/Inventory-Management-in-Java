/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package inventory.Template;

/**
 *
 * @author SIMI
 */
public class alltemplate {
    String department,type;

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
    
}
