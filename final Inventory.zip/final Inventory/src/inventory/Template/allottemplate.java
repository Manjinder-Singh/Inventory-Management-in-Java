/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package inventory.Template;

/**
 *
 * @author SIMI
 */
public class allottemplate {
    String department,labs,type,name,monthofpurchase,monthofallocation;
    int noofitems,year,dateofpurchase,yearofpurchase,dateofallocation,yearofallocation;

    public int getDateofallocation() {
        return dateofallocation;
    }

    public void setDateofallocation(int dateofallocation) {
        this.dateofallocation = dateofallocation;
    }

    public String getMonthofallocation() {
        return monthofallocation;
    }

    public void setMonthofallocation(String monthofallocation) {
        this.monthofallocation = monthofallocation;
    }

    public int getYearofallocation() {
        return yearofallocation;
    }

    public void setYearofallocation(int yearofallocation) {
        this.yearofallocation = yearofallocation;
    }

    public int getYear() {
        return year;
    }

    public int getDateofpurchase() {
        return dateofpurchase;
    }

    public void setDateofpurchase(int dateofpurchase) {
        this.dateofpurchase = dateofpurchase;
    }

    public String getMonthofpurchase() {
        return monthofpurchase;
    }

    public void setMonthofpurchase(String monthofpurchase) {
        this.monthofpurchase = monthofpurchase;
    }

    public int getYearofpurchase() {
        return yearofpurchase;
    }

    public void setYearofpurchase(int yearofpurchase) {
        this.yearofpurchase = yearofpurchase;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getLabs() {
        return labs;
    }

    public void setLabs(String labs) {
        this.labs = labs;
    }

    public int getNoofitems() {
        return noofitems;
    }

    public void setNoofitems(int noofitems) {
        this.noofitems = noofitems;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
    
}
