/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package inventory.service;

import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;

/**
 *
 * @author SIMI
 */
public class monthOperationDB {
    DB db;
   public monthOperationDB()//constructor call first
    {
        db=ConnectionDB.conDB();//return type db than return database
        
    }
   public DBCursor searchMonthly(String monthofpurchase,int yearofpurchase)
   {
       System.out.print("monthofpurchase");
    DBCollection table=db.getCollection("stock_record");
     BasicDBObject searchquery=new BasicDBObject();
     searchquery.put("monthofpurchase",monthofpurchase);
          searchquery.put("yearofpurchase",yearofpurchase);
   BasicDBList list=new BasicDBList();
     list.add(searchquery);
     
     BasicDBObject search=new BasicDBObject();
     search.put("$and", list);
     
     DBCursor cursor=table.find(search);
     return cursor;
     

}
}
