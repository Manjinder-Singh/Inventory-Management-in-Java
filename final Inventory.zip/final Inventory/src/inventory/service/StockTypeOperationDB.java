/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package inventory.service;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import inventory.Template.StockTypeTemplate;

/**
 *
 * @author SIMI
 */
public class StockTypeOperationDB {
     DB db;
   public StockTypeOperationDB()//constructor call first
    {
        db=ConnectionDB.conDB();//return type db than return database
        
    }
public DBCursor searchStocktype(String stocktype)
{
    System.out.println(stocktype);
    DBCollection table=db.getCollection("stock_record");
     BasicDBObject searchquery=new BasicDBObject();
     searchquery.put("stocktype",stocktype);
     DBCursor cursor=table.find(searchquery);
     return cursor;
}
}
