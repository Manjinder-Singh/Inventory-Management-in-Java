/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package inventory.service;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import inventory.Template.allottemplate;

/**
 *
 * @author SIMI
 */
public class allotOperationDB {
 DB db;
 public allotOperationDB()
   {
        db=ConnectionDB.conDB();//return type db than return database
   }
    public void Saveallot(allottemplate T)
    {
     DBCollection table=db.getCollection("stock");//collection enteries
     BasicDBObject document=new BasicDBObject();//create documentthn enter info
     document.put("department",T.getDepartment());
     document.put("labs",T.getLabs());
     document.put("types",T.getType());
     document.put("name", T.getName());
     document.put("noofitems",T.getNoofitems());
    table.insert(document);
     }
    
    
    
 
}
