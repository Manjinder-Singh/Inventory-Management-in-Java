/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package inventory;

/**
 *
 * @author SIMI
 */
class jComboBox8 {

    static int getItemCount() {
        throw new UnsupportedOperationException("Not yet implemented");
    }

    static void removeItemAt(int i) {
        throw new UnsupportedOperationException("Not yet implemented");
    }

    static void repaint() {
        throw new UnsupportedOperationException("Not yet implemented");
    }

    static void addItem(Object get) {
        throw new UnsupportedOperationException("Not yet implemented");
    }
    
}
